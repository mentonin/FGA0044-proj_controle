N = 5;
[ aceito, per_fora_menos, per_fora_mais, per_ok ] = testeHipotese(mean_eps,2,N)
[ aceito, per_fora_menos, per_fora_mais, per_ok ] = testeHipoteseGaussiana(mean_eps_i,N)