N = 5;
[ aceito, per_fora_menos, per_fora_mais, per_ok ] = testeHipotese(mean_eps_r,1,N)
[ aceito, per_fora_menos, per_fora_mais, per_ok ] = testeHipoteseGaussiana(mean_eps_ri,N)