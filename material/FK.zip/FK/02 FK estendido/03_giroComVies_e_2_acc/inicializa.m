T = 0.01;

Ad = 1;
Bd = T;

Ad_K = [1 -T;
        0 1];      
Bd_K = [ T;
         0];
Bd_n = [T      0;
        0      1];



    
